module.exports = 
{
    "URI": "mongodb://localhost/bookStore"
}